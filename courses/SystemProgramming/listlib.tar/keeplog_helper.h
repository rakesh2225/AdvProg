int runproc (char* cmd);
void showhistory (FILE* f);
